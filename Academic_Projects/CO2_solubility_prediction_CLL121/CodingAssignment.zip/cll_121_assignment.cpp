#include<iostream> 
#include<vector>
#include<cmath>
#include<iomanip>
#include<fstream>
#include<iostream>

using namespace std;

long double water_density(long double P, long double T0){

    long double Vo = (1.0l +(18.1597l * powl(10.0l,-3.0l) * (T0)))/( 0.9998l + (18.2249l*powl(10.0l,-3.0l)*(T0))
    - (7.9222l*powl(10.0l,-6.0l)*powl((T0),2.0l)) - (55.4485l*powl(10.0l,-9.0l)*powl((T0),3.0l)) + (149.7562l*powl(10.0l,-12.0l)
    *powl((T0),4.0l)) - (393.2952l*powl(10.0l,-15.0l)*powl((T0),5.0l)));

    long double B = 19654.32l + 147.037l*T0 - (2.2155l*powl(T0,2.0l)) + (1.0478l*powl(10.0l,-2.0l)*powl(T0,3.0l)) - 
    (2.2789l*powl(10.0l,-5.0l)*powl(T0,4.0l));

    long double A1 = 3.2891l - (2.391l*powl(10.0l,-3.0l)*T0) + (2.8446l*powl(10.0l,-4.0l)*powl(T0,2.0l)) - (2.82l*powl(10.0l,-6.0l)*powl(T0,3.0l))
    + (8.477l*powl(10.0l,-9.0l)*powl(T0,4.0l));

    long double A2 = 6.245l*powl(10.0l,-5.0l) - (3.913l*powl(10.0l,-6.0l)*T0) - (3.499l*powl(10.0l,-8.0l)*powl(T0,2.0l))
    + (7.942l*powl(10.0l,-10.0l)*powl(T0,3.0l)) - (3.299l*powl(10.0l,-12.0l)*powl(T0,4.0l));

    long double rhoinverse = Vo - ((Vo*P)/(B + A1*P + A2*powl(P,2.0l)));
    long double rhow = powl(rhoinverse,-1.0l);
    
    return rhow;
}

long double water_fugacity(long double P, long double T, long double rho, long double R){
    long double Tcw = 647.096l; 
    long double Pcw = 220.64l; // bar
    long double Tr = T/Tcw;
    long double k = 1.0l-Tr;


    // constants 
    long double a1 = -7.8595178l;
    long double a2 =  1.8440825l;
    long double a3 = -11.786649l;
    long double a4 = 22.680741l;
    long double a5 = -15.9618719l;
    long double a6 = 1.8012250l;

    long double lnpspc = (1.0l/Tr)*( a1*k + (a2*powl(k,1.5l)) + (a3*powl(k,3.0l)) + (a4*powl(k,3.5l)) 
    + (a5*powl(k,4.0l)) + (a6*powl(k,7.5l)));

    long double Ps = Pcw*expl(lnpspc); // in bar
    long double fh2o = Ps*exp(18.0152l*(P-Ps)/(R*T*rho));

    return fh2o;
}

long double secondO_Iparameter(long double P, long double T){
    long double lc1 = -0.0652869l;
    long double lc2 = 1.6790636l*powl(10.0l,-4.0l);
    long double lc3 = 40.838951l;
    long double lc4 = 0.0l;
    long double lc5 = 0.0l;
    long double lc6 = -3.9266518l*pow(10.0l,-2.0l);
    long double lc7 =0.0l;
    long double lc8 = 2.1157167l*pow(10.0l,-2.0l);
    long double lc9 = 6.5486487l*pow(10.0l,-6.0l);
    long double lc10 = 0.0l;

    long double lamdaCo2Na = lc1 + (lc2*T) + (lc3/T) + (lc4*P) + (lc5/P) + (lc6*P/T) + (lc7*T/powl(P,2.0l)) + 
    (lc8*P/(630.0l-T)) + (lc9*T*logl(P)) + (lc10*P/powl(T,2.0l));



    return lamdaCo2Na;
}

long double thirdO_Iparameter(long double P, long double T){

    long double ec1 = -1.144624l*powl(10.0l,-2.0l);
    long double ec2 = 2.8274958l*powl(10.0l,-5.0l);
    long double ec3 = 0.0l;
    long double ec4 = 0.0l;
    long double ec5 = 0.0l;
    long double ec6 = 1.3980876l*pow(10.0l,-2.0l);
    long double ec7 = 0.0l;
    long double ec8 = -1.4349005l*pow(10.0l,-2.0l);
    long double ec9 = 0.0l;
    long double ec10 = 0.0l;

    long double ECo2Nacl = ec1 + (ec2*T) + (ec3/T) + (ec4*P) + (ec5/P) + (ec6*P/T) + (ec7*T/powl(P,2.0l)) + 
    (ec8*P/(630.0l-T)) + (ec9*T*logl(P)) + (ec10*P/powl(T,2.0l));

    return ECo2Nacl;
}

int main(){

    ifstream Input_file("Input.txt");
    ofstream Output_file("Output.txt");
    vector<long double> inputs;
    long double data;
    while(!Input_file.eof()){
        Input_file>>data;
        inputs.push_back(data);
    }
    Input_file.close();
    int array_size = inputs.size();
    int array_iterator = 0;
    while(array_iterator<=array_size-3){
        long double T,P,m;
        P = inputs[array_iterator];
        T = inputs[array_iterator+1];
        m = inputs[array_iterator+2];
        
        long double theta = T - 273.15l;
        long double Tc = 304.128l; // K
        long double Pc = 73.77l ; // bar
        long double Tr = T/Tc; 
        long double Pr = P/Pc; 
        long double R = 83.144598l; // cm3 bar K-1 mol-1

        // Parameters for PR EOS
        long double s = 1.0l + sqrtl(2.0l);
        long double e = 1.0l - sqrt(2.0l);
        long double o = 0.077796l;
        long double sh = 0.457236l;
        long double w = 0.224l;
        long double al = 1.0l + (0.37464l + 1.54226l*w - 0.26992l*powl(w,2.0l))*
                        (1.0l - sqrtl(Tr));
        long double apr = powl(al,2.0l);
        long double b = o*Pr/Tr;
        long double q = sh*apr/(o*Tr);

        // PR EOS Z calculation using fixed point iteration method
        int i = 2000;
        long double Z = 1.0l;
        while(i>0){
            long double tol = 1e-8l; // tolerance
            long double Zn = (1.0l + b) - ( (q*b)*(Z - b)/((Z+e*b)*(Z+s*b)) ); // calculated value

            if(fabsl(Z-Zn)<tol){ // close after desired tolerance achived 
                break;
            }
            Z = Zn; 
            i--;
        }

        // Residual Property I 
        long double I = (1.0l/(s-e))*logl((Z+s*b)/(Z+e*b));

        // phi coefficient of fugacity calculation
        long double lnphi = Z - 1.0l - logl(Z - b) - q*I;
        long double phi = expl(lnphi);

        // ρH2O°, pure water density 
        long double rho_h2o = water_density(P,theta); // g/cm3

        //fH2O°, water fugacity calculation 
        long double fh2o = water_fugacity(P,T,rho_h2o,R); // bar


        //hco2 calculation 
        long double neta = -0.114535l;
        long double deltaB = -5.279063l + (6.187967l*powl((powl(10.0l,3.0l)/T),0.5l));
        long double lnhco2 = neta*logl(R*T*rho_h2o/(18.0152l)) + (1.0l-neta)*log(fh2o) + 2.0l*rho_h2o*deltaB;
        long double hco2 = expl(lnhco2); // bar 

        // γi Activity coefficients of dissolved gases
        long double co2_na = secondO_Iparameter(P,T);
        long double co2_na_cl = thirdO_Iparameter(P,T);

        long double lngco2 = 2.0l*m*co2_na + 2.0l*powl(m,2.0l)*co2_na_cl; 
        long double gco2 = expl(lngco2);

        // Kco2 calculation
        long double Kco2 = hco2*gco2/(P*phi);

        // Kh2o calculation
        long double lnkh20 = -2.209l + ( 3.097l * powl(10.0l,-2.0l)*theta ) - 1.098l*powl(10.0l,-4.0l)*powl(theta,2.0l)
        + 2.048l * powl(10.0l,-7.0l) * powl(theta,3.0l);

        long double kh20 = powl(10.0l,(lnkh20));
        long double exp_h2o = expl((P-1.0l)*18.18l/(R*T));
        long double Kh2o = kh20*exp_h2o/(fh2o*P);

        // yh2o calculation
        long double yh2o = (1.0l - (1.0l/Kco2))/((1.0l/Kh2o) - (1.0l/Kco2));
        
        // yin calculation
        long double yin = 1.0l/(1.0l+yh2o);

        // xi calculation 
        long double xi = yin/Kco2;

        Output_file<<phi<<" ";
        Output_file<<hco2<<" ";
        Output_file<<Kh2o<<" ";
        Output_file<<yh2o<<" ";
        Output_file<<xi<<"\n";
        array_iterator+=3;
    }
    Output_file.close();
    return 0;
}
